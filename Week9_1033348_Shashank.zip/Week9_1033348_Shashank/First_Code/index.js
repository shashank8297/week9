function form() {
    const name = document.getElementById("first").value;
    const email = document.getElementById("email").value;
    const rate = document.getElementById("rate").value;
    const where = document.getElementById("where").value;
    const morning = document.getElementById("morning").value;
    const evening = document.getElementById("evening").value;
    const afternoon = document.getElementById("afternoon").value;
    const experience = document.getElementById("experience").value;

    console.log(where);
    if (name === "") {
        alert("Name shouldn't be empty.");
        return false;
    }
    else if(email === ""){
        alert("E-mail shouldn't be empty.");
        return false;
    }
    else if(rate === ""){
        alert("Rating shouldn't be empty.");
        return false;
    }
    else if(where==="select"){
        alert("Plese select Location.");
        return false;
    }
    /*else if(!morning.checked) {   
        alert("Plese select Time.");
        return false;
    }   
    else if(!evening.checked) {   
        alert("Plese select Time.");
        return false;
    }   
    else if(!afternoon.checked) {   
        alert("Plese select Time.");
        return false;
    }
    */
    else if(experience === ""){
        alert("Plese Describe your Experience.");
        return false;
    }
    else{
        return true;
    }
}